# Dino_King
THIS IS DINO KING VIP BYPASSED TOLLS

apt update

apt upgrade -y

apt install python -y

apt install python2 -y

apt install git

pip2 install requests

pip2 install mechanize

pip2 install bs4

git clone https://github.com/DINO786/Dino_King

cd Dino_King

python2 Dino_King.py

Enjoy❤😌
